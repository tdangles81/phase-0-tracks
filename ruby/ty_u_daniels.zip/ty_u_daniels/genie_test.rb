require_relative 'genie'

describe Genie do 
	let (:genie) {Genie.new("Gypsy", 25)}

	it "grants wish" do
		genie.grant_wish("i wish i had $100")
	end

	it "checks for wish w/ most vowels" do 
		genie.grant_wish("i wish i had a cat")
		genie.grant_wish("aeiou i wish i had a cat")
		expect(genie.favorite_wish).to eq ["aeiou i wish i had a cat", true]
	end
end