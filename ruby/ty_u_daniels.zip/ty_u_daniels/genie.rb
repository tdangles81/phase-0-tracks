#Create a CLASS where a genie takes wishes, decides whether or not to 
#grant them based on the number of wishes asked, and ITERATES through wishes
#to find the one with the most vowels.
class Genie
	attr_accessor :name

#Set up genie name and age when file is loaded,
#to be used by the rest of the CLASS.
	def initialize(name,age)
		@name = name
		@age = age
		@submitted_wishes = {}
	end

#Make the genie go back into the lamp when they are not being requested.
	def enter_lamp
		puts "Goodbye for now!"
	end

#Make the genie come out of the lamp when a wish is being granted.
	def exit_lamp
		puts "#{@name} is here to consider your wish!"
	end

#Give a place for genie to take a wish to grant if no more than three
#wishes have been granted. Keep it saved and remember whether or not that 
#particular wish was granted.
	def grant_wish(wish)
		exit_lamp
		if @submitted_wishes.length <= 2
			puts "Your wish of '#{wish}' has been granted!"
			@submitted_wishes[wish] = true
		else
			puts "Sorry, I've already granted three wishes today!"
			@submitted_wishes[wish] = false
		end
		enter_lamp
	end

#Keep a log of all wishes that were asked of the genie, whether or nor granted.
	def display_wish_history
		@submitted_wishes.each do |k,v|
			puts "The wish '#{k}' was granted #{v}."
		end
	end

#Once all wishes have been granted (or not), sift through all of the wishes and
#find the one with the greates number of vowels.
	def favorite_wish
		puts "The genie #{@name}'s favorite wish: "
		p @submitted_wishes.max_by{|k,v| k.scan(/[aeiou]/).count}
	end
end

#DRIVER
#Uncomment to run RSpec tests from genie_test.rb
genie = Genie.new("Gypsy", 30)
puts genie.name
new_name = genie.name = "Sebastian"
puts genie.name
genie.exit_lamp
genie.enter_lamp

wishes = ["i wish i had $100", "i wish i could fly", "i wish i had a cat", "i wish i was awesome at Ruby", "i wish i was Kylo Ren"]
wishes.each do |wish|
	genie.grant_wish(wish)
end

genie.display_wish_history
genie.favorite_wish


